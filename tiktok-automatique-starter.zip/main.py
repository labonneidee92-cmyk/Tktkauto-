import os

def main():
    print("🚀 TikTok Automatique - Starter")
    print("1. Collecte vidéos (Pexels, YouTube CC)")
    print("2. Génération script IA")
    print("3. Voix-off ElevenLabs / OpenAI")
    print("4. Montage automatique (MoviePy)")
    print("5. Export .mp4 prêt à poster")

if __name__ == "__main__":
    main()
