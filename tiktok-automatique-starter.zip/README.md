# TikTok Automatique — Starter

Agent IA (version simplifiée) pour générer des vidéos TikTok sur l’aviation : collecte de vidéos (Pexels + YouTube CC), script, voix-off, montage, export — **tu publies manuellement**.

## ⚙️ Prérequis rapides
- Compte **GitHub** + **Codespaces** (ou Replit).
- Clés API : **Pexels**, **YouTube Data API v3**, (optionnel) **ElevenLabs** et **OpenAI**.
- FFmpeg installé.

## Installation (Codespaces)
1. Ouvre ton repo dans Codespaces.
2. Copie `.env.example` → `.env` et renseigne tes clés.
3. Installe les deps :
```bash
pip install -r requirements.txt
```
4. Installe FFmpeg :
```bash
sudo apt-get update && sudo apt-get install -y ffmpeg
```

## Lancer le script
```bash
python main.py
```
